import PropTypes from 'prop-types';

export default {
  clickOnLogo: PropTypes.func.isRequired
};
