import React from 'react';

function Spacer() {
  return (
    <div className='spacer' />
  );
}

Spacer.displayName = 'Spacer';

export default Spacer;
