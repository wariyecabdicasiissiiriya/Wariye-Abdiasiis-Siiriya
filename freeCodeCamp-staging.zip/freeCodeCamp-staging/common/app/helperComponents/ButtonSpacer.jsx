import React from 'react';

function ButtonSpacer() {
  return (
    <div className='button-spacer' />
  );
}

ButtonSpacer.displayName = 'ButtonSpacer';

export default ButtonSpacer;
