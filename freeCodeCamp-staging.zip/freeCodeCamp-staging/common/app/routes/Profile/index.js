import { types } from './redux';

export { default } from './Profile.jsx';

export const routes = {
  [types.onRouteProfile]: '/:username'
};
