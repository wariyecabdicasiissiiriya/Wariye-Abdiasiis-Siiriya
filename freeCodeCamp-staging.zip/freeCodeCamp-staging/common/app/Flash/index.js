export { default } from './Flash.jsx';
